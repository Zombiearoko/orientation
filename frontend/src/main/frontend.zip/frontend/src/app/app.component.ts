import { Component } from '@angular/core';
import { HomePage } from '../pages/home/home';
@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	 rootPage:any =HomePage;
    title = 'app';
	constructor(){}
	
}

